//
//  NIViewController.m
//  NIDropDown
//
//  Created by Bijesh N on 12/28/12.
//  Copyright (c) 2012 Nitor Infotech. All rights reserved.
//

#import "NIViewController.h"
#import "NIDropDown.h"
#import "QuartzCore/QuartzCore.h"

@interface NIViewController ()

@end

@implementation NIViewController

@synthesize btnSelect, Select2, Select3, btnSelect4, Select5;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    btnSelect.layer.borderWidth = 1;
    btnSelect.layer.borderColor = [[UIColor blackColor] CGColor];
    btnSelect.layer.cornerRadius = 5;
    
    Select2.layer.borderWidth = 1;
    Select2.layer.borderColor = [[UIColor redColor] CGColor];
    Select2.layer.cornerRadius = 5;
    
    Select3.layer.borderWidth = 1;
    Select3.layer.borderColor = [[UIColor blackColor] CGColor];
    Select3.layer.cornerRadius = 5;
    
    btnSelect4.layer.borderWidth = 1;
    btnSelect4.layer.borderColor = [[UIColor yellowColor] CGColor];
    btnSelect4.layer.cornerRadius = 5;
    
    Select5.layer.borderWidth = 1;
    Select5.layer.borderColor = [[UIColor greenColor] CGColor];
    Select5.layer.cornerRadius = 5;
}

- (void)viewDidUnload {
//    [btnSelect release];
//    btnSelect = nil;
//    [self setBtnSelect:nil];
    
    
    
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
//    [btnSelect release];
//    [super dealloc];
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
    NSLog(@"%@", btnSelect.titleLabel.text);
}

- (IBAction)selectClicked:(id)sender {
    [self openDropDwonMenu:sender];
   }

- (IBAction)Select2:(UIButton *)sender {
    [self openDropDwonMenu:sender];
}

- (IBAction)Select3:(UIButton *)sender {
    [self openDropDwonMenu:sender];
}


- (IBAction)clickSelect4:(UIButton *)sender {
    [self openDropDwonMenu:sender];
}

- (IBAction)Select5:(UIButton *)sender {
    [self openDropDwonMenu:sender];
}

-(void)openDropDwonMenu:(UIButton *)sender {
    NSArray * arr = [[NSArray alloc] init];
    arr = [NSArray arrayWithObjects:@"0 Hello 0", @"1 Hello 1", @"2 Hello 2", @"3 Hello 3", @"4 Hello 4", @"5 Hello 5", @"6 Hello 6", @"7 Hello 7", @"8 Hello 8", @"9 Hello 9",nil];
    NSArray * arrImage = [[NSArray alloc] init];
    arrImage = [NSArray arrayWithObjects:[UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], [UIImage imageNamed:@"apple.png"], [UIImage imageNamed:@"apple2.png"], nil];
    if(dropDown == nil) {
        CGFloat f = 200;
        dropDown = [[NIDropDown alloc]showDropDown:sender :&f :arr :arrImage :@"down"];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
        [self rel];
    }

}
-(void)rel{
//    [dropDown release];
    dropDown = nil;
}


@end
